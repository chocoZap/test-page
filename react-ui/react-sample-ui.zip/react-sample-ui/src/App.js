import './styles/global.css';
import HomePage from './components/pages/HomePage';

function App() {
  return <HomePage />;
}

export default App;
