import { useMemo, useState } from 'react';
import profiles from '../../data/profiles';
import SearchForm from '../molecules/SearchForm';
import ProfileList from '../organisms/ProfileList';
import ProfileDirectoryTemplate from '../templates/ProfileDirectoryTemplate';

function HomePage() {
  const [inputValue, setInputValue] = useState('');
  const [keyword, setKeyword] = useState('');

  const filteredProfiles = useMemo(() => {
    const normalizedKeyword = keyword.trim().toLowerCase();

    if (!normalizedKeyword) {
      return profiles;
    }

    return profiles.filter((profile) => {
      const searchableText = `${profile.name} ${profile.role}`.toLowerCase();
      return searchableText.includes(normalizedKeyword);
    });
  }, [keyword]);

  const handleKeywordChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSearch = () => {
    setKeyword(inputValue);
  };

  return (
    <ProfileDirectoryTemplate
      searchArea={
        <SearchForm
          keyword={inputValue}
          onKeywordChange={handleKeywordChange}
          onSearch={handleSearch}
        />
      }
      contentArea={<ProfileList profiles={filteredProfiles} />}
    />
  );
}

export default HomePage;
