# React Sample - Atomic Design 模範解答

このプロジェクトは、プロフィールカード一覧ページを React で実装した模範解答です。

## 主なポイント

- Create React App ベースの構成をそのまま利用
- Atomic Design を意識したフォルダ分割
- `props` でデータ受け渡し
- `useState` で詳細表示の開閉を制御
- `map` でカード一覧を描画

## フォルダ構成

```text
src/
  components/
    atoms/
    molecules/
    organisms/
    templates/
    pages/
  data/
  styles/
```

## 起動方法

```bash
npm install
npm start
```

## Atomic Design の役割

- `atoms`: 最小単位の UI 部品
- `molecules`: atoms を組み合わせた小さな部品
- `organisms`: 画面の意味あるまとまり
- `templates`: レイアウトの骨格
- `pages`: 状態管理と画面全体の組み立て
