# HTML,CSS基礎 サンプルUI

HTML / CSS基礎モジュール用のサンプルUIです。

## ファイル構成
- `index.html` : サンプル画面本体
- `style.css` : スタイル定義

## 想定学習ポイント
- セマンティックタグ（header / main / section / article / footer）
- Flexboxによるカードの横並び
- 余白、色、枠線、影の基本
- hoverスタイル
- media queryによるレスポンシブ対応

## 使い方
1. `index.html` をブラウザで開く
2. HTML構造とCSSの対応関係を確認する
3. レイアウトや余白を変更して挙動を試す
