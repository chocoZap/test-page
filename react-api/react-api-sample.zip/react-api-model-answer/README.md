# React + API モジュール 模範解答

このディレクトリは、React + API モジュールの模範解答です。

## この模範解答で扱っていること

- Reactでのコンポーネント分割
- `fetch` を使ったAPI通信
- `loading / error / 空データ` の表示切り替え
- 検索条件の state 管理
- Atomic Design を意識したフォルダ構成

## 使用API

- JSONPlaceholder の `/users`

## 起動方法

```bash
npm install
npm start
```

ブラウザで `http://localhost:3000` を開いて確認してください。

## テスト実行

```bash
npm test
```

## 主なディレクトリ構成

```text
src/
├─ components/
│  ├─ atoms/
│  ├─ molecules/
│  ├─ organisms/
│  ├─ templates/
│  └─ pages/
├─ hooks/
│  └─ useUsers.js
└─ utils/
   └─ filterUsers.js
```

## 補足

- UIの責務とAPI取得の責務を分けるため、API通信は `useUsers.js` に切り出しています。
- 検索処理は `filterUsers.js` に分け、画面側でロジックが膨らみすぎないようにしています。
