import { useEffect, useState } from 'react';

const USERS_API_URL = 'https://jsonplaceholder.typicode.com/users';

/**
 * ユーザー一覧取得用のカスタムHook
 *
 * このモジュールでは、以下の責務をここにまとめています。
 * - API通信を実行する
 * - loading / error / data の状態を管理する
 *
 * 画面コンポーネント側には「表示に必要な値」だけを返すことで、
 * UIの責務とデータ取得の責務を大きく分けています。
 */
function useUsers() {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    let ignore = false;

    const fetchUsers = async () => {
      setIsLoading(true);
      setErrorMessage('');

      try {
        const response = await fetch(USERS_API_URL);

        if (!response.ok) {
          throw new Error('ユーザー情報の取得に失敗しました。');
        }

        const data = await response.json();

        // 画面がアンマウントされた後の state 更新を避けるためのガードです。
        if (!ignore) {
          setUsers(data);
        }
      } catch (error) {
        if (!ignore) {
          setErrorMessage(
            error instanceof Error
              ? error.message
              : '予期しないエラーが発生しました。'
          );
        }
      } finally {
        if (!ignore) {
          setIsLoading(false);
        }
      }
    };

    fetchUsers();

    return () => {
      ignore = true;
    };
  }, []);

  return {
    users,
    isLoading,
    errorMessage,
  };
}

export default useUsers;
