import Heading from '../atoms/Heading';
import Text from '../atoms/Text';

function PageHeader() {
  return (
    <header className="page-header">
      <Text className="site-name">Frontend Training</Text>
      <Heading>ユーザー一覧</Heading>
      <Text className="page-lead">
        Reactでコンポーネント分割を行い、APIから取得したデータを一覧表示する模範解答です。
      </Text>
    </header>
  );
}

export default PageHeader;
