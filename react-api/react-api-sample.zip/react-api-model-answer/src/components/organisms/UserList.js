import StatusMessage from '../atoms/StatusMessage';
import UserCard from './UserCard';

function UserList({ users }) {
  if (users.length === 0) {
    return (
      <StatusMessage>
        該当するデータがありません。
      </StatusMessage>
    );
  }

  return (
    <section className="card-grid">
      {users.map((user) => (
        <UserCard key={user.id} user={user} />
      ))}
    </section>
  );
}

export default UserList;
