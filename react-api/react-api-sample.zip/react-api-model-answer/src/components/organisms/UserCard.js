import Button from '../atoms/Button';
import UserCardBody from '../molecules/UserCardBody';

function UserCard({ user }) {
  const handleClick = () => {
    // 今回の課題では画面遷移は不要なので、押下確認用に console.log を出しています。
    console.log(`詳細ボタンが押されました: ${user.name}`);
  };

  return (
    <article className="card">
      <UserCardBody user={user} />
      <Button onClick={handleClick}>詳細を見る</Button>
    </article>
  );
}

export default UserCard;
