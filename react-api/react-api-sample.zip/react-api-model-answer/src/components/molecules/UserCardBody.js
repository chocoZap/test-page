import Text from '../atoms/Text';

function UserCardBody({ user }) {
  return (
    <div className="card-body">
      <Text className="card-name">{user.name}</Text>
      <Text className="card-username">@{user.username}</Text>
      <Text className="card-email">{user.email}</Text>
      <Text className="card-company">{user.company?.name}</Text>
    </div>
  );
}

export default UserCardBody;
