import { useMemo, useState } from 'react';
import StatusMessage from '../atoms/StatusMessage';
import SearchForm from '../molecules/SearchForm';
import UserList from '../organisms/UserList';
import UserDirectoryTemplate from '../templates/UserDirectoryTemplate';
import useUsers from '../../hooks/useUsers';
import filterUsers from '../../utils/filterUsers';

function HomePage() {
  // inputValue: 入力欄に今入っている値
  // keyword: 実際に検索条件として適用する値
  // 分けることで「ボタン押下で検索」の形を作っています。
  const [inputValue, setInputValue] = useState('');
  const [keyword, setKeyword] = useState('');

  const { users, isLoading, errorMessage } = useUsers();

  const filteredUsers = useMemo(() => {
    return filterUsers(users, keyword);
  }, [users, keyword]);

  const handleKeywordChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSearch = () => {
    setKeyword(inputValue);
  };

  let contentArea = <UserList users={filteredUsers} />;

  if (isLoading) {
    contentArea = <StatusMessage>読み込み中です...</StatusMessage>;
  }

  if (errorMessage) {
    contentArea = <StatusMessage variant="error">{errorMessage}</StatusMessage>;
  }

  return (
    <UserDirectoryTemplate
      searchArea={
        <SearchForm
          keyword={inputValue}
          onKeywordChange={handleKeywordChange}
          onSearch={handleSearch}
        />
      }
      contentArea={contentArea}
    />
  );
}

export default HomePage;
