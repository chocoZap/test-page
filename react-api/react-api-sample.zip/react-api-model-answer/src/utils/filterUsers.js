/**
 * 検索キーワードに応じて、ユーザー一覧を絞り込みます。
 *
 * 今回は以下を検索対象にしています。
 * - 名前
 * - メールアドレス
 * - 会社名
 */
function filterUsers(users, keyword) {
  const normalizedKeyword = keyword.trim().toLowerCase();

  if (!normalizedKeyword) {
    return users;
  }

  return users.filter((user) => {
    const searchableText = `${user.name} ${user.email} ${user.company?.name ?? ''}`.toLowerCase();

    return searchableText.includes(normalizedKeyword);
  });
}

export default filterUsers;
